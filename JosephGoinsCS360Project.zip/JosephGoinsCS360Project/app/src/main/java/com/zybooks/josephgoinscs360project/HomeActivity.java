package com.zybooks.josephgoinscs360project;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.Collection;

public class HomeActivity extends AppCompatActivity {
    /*
        Array list for inventory items. Test data is added for now but can later be
        pulled from database.
    */
    private ArrayList<InventoryItem> items = new ArrayList<>();
    private InventoryItemDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_home);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        /*
            Set up add item click.
        */
        Button addItemBtn = findViewById(R.id.addItemButton);

        addItemBtn.setOnClickListener(view -> {
            Intent intent = new Intent(HomeActivity.this, AddItem.class);
            startActivity(intent);
        });

        /*
            Set up add SMS Notification click.
        */
        Button smsNotificationBtn = findViewById(R.id.addSMSNotificationsButton);

        smsNotificationBtn.setOnClickListener(view -> {
            Intent intent = new Intent(HomeActivity.this, SmsNotification.class);
            startActivity(intent);
        });

        db = new InventoryItemDatabase(this);
        items = db.getAllItems();

        /*
            Targets the recycler view on the activity_home.xml.
            Then it sets it's layout to use a GridLayout with a column span of 2.
            Lastly, it sets the adapter equal to my InventoryAdapter.java class.
            The adapter will feed the backend data into the inventory_item.xml and provide it to
            the RecyclerView.
        */
        RecyclerView recyclerView = findViewById(R.id.inventoryRecyclerView);

        recyclerView.setLayoutManager(
                new GridLayoutManager(this, 2)
        );

        InventoryAdapter adapter = new InventoryAdapter(items, db);
        recyclerView.setAdapter(adapter);
    }
}