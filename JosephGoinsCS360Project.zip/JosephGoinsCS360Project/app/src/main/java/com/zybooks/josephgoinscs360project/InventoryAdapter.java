package com.zybooks.josephgoinscs360project;

import android.Manifest;
import android.content.pm.PackageManager;
import android.telephony.SmsManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.zybooks.josephgoinscs360project.R;

import java.util.ArrayList;

public class InventoryAdapter extends RecyclerView.Adapter<InventoryAdapter.ViewHolder> {
    /*
        private variable for holding data inventory items.
    */

    private final ArrayList<InventoryItem> items;
    InventoryItemDatabase db;

    /*
        constructor that takes in the array list of items.
    */
    public InventoryAdapter(ArrayList<InventoryItem> items, InventoryItemDatabase db) {
        this.items = items;
        this.db = db;
    }

    /*
        OnCreateViewHolder takes in the parent view and view type.
        It then creates an inflated view using the inventory_item.xml layout.
        It returns that view to the ViewHolder method.
    */
    @NonNull
    @Override
    public InventoryAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.inventory_item, parent, false);

        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull InventoryAdapter.ViewHolder holder, int position) {
        /*
            When the ViewHolder is binded to the RecylerView it sets the component text equal
            to the items data based on the arrays position(Index).
        */
        InventoryItem item = items.get(position);

        holder.itemName.setText(item.getItemName());
        holder.itemDescription.setText(item.getItemDescription());
        holder.itemQty.setText(String.valueOf(item.getItemQuantity()));

        holder.deleteBtn.setOnClickListener(v -> {
            String name = item.getItemName();
            int currentPosition = holder.getBindingAdapterPosition();

            boolean result = db.deleteInventoryItem(name);

            if (result) {
                items.remove(currentPosition);
                notifyItemRemoved(currentPosition);
            }
        });

        /*
            * This grabs the current items name and qty. It prevents quantity
            * removal if zero so that quantity cannot be negative. It then
            * changes the quantity and checks if zero quantity and SMS permissions
            * granted. If granted it sends an sms message notification. Lastly, if the database
            * is successfully updated it changes the UI.
        */
        holder.removeQtyBtn.setOnClickListener(v -> {
            String name = item.getItemName();
            int qty = item.getItemQuantity();

            if (qty == 0) return;

            int changedQty = qty - 1;

            if ((changedQty == 0) && (ContextCompat.checkSelfPermission(holder.itemView.getContext(), Manifest.permission.SEND_SMS)
                    == PackageManager.PERMISSION_GRANTED)) {
                SmsManager smsManager = SmsManager.getDefault();

                smsManager.sendTextMessage("5554", null, name + " is out of stock", null, null);
            }

            boolean result = db.changeQuantityFromItem(name, changedQty);

            if (result) {
                item.setItemQuantity(changedQty);
                holder.itemQty.setText(String.valueOf(changedQty));
            }
        });

        /*
            * Performs the quantity changed the same way as the removal.
            * Refer to removeQtyBtn click event for any questions in IventoryAdapter.java
            * lines 74 through 80 for commented functionality.
        */
        holder.addQtyBtn.setOnClickListener(v -> {
            String name = item.getItemName();
            int qty = item.getItemQuantity() + 1;

            boolean result = db.changeQuantityFromItem(name, qty);

            if (result) {
                item.setItemQuantity(qty);
                holder.itemQty.setText(String.valueOf(qty));
            }
        });
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        /*
            Create Java variables that are then connected to the view components by ID.
        */
        TextView itemName;
        TextView itemDescription;
        TextView itemQty;
        FloatingActionButton deleteBtn;
        FloatingActionButton removeQtyBtn;
        FloatingActionButton addQtyBtn;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            itemName = itemView.findViewById(R.id.itemNameText);
            itemDescription = itemView.findViewById(R.id.itemDescriptionText);
            itemQty = itemView.findViewById(R.id.itemQtyText);

            deleteBtn = itemView.findViewById(R.id.deleteInventoryItem);
            removeQtyBtn = itemView.findViewById(R.id.removeQtyButton);
            addQtyBtn = itemView.findViewById(R.id.addQtyButton);
        }
    }
}
