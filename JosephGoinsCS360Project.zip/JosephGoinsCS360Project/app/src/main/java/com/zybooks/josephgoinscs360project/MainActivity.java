package com.zybooks.josephgoinscs360project;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    private UserDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        db = new UserDatabase(this);

        /*
        Targets the login in.
        Sets the click event with the intent on the main activity view to navigate to
        the home activity. This is a temporary navigation setup without identity check.
        */
        Button loginButton = findViewById(R.id.loginButton);
        Button registerButton = findViewById(R.id.registerButton);

        loginButton.setOnClickListener(view -> {
            TextView usernameField = findViewById(R.id.usernameLoginText);
            TextView passwordField = findViewById(R.id.passwordLoginText);
            String username = usernameField.getText().toString();
            String password = passwordField.getText().toString();

            boolean isValidUser = db.validateUser(username, password);

            if (isValidUser) {
                Intent intent = new Intent(MainActivity.this, HomeActivity.class);
                startActivity(intent);
            }
        });

        // Registers the users login information.
        registerButton.setOnClickListener( view -> {
            TextView usernameField = findViewById(R.id.usernameLoginText);
            TextView passwordField = findViewById(R.id.passwordLoginText);
            String username = usernameField.getText().toString();
            String password = passwordField.getText().toString();

            db.createUser(username, password);
        });
    }
}