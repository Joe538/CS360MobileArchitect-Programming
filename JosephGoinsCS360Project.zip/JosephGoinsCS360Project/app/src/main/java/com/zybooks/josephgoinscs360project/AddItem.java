package com.zybooks.josephgoinscs360project;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class AddItem extends AppCompatActivity {
    private InventoryItemDatabase db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_add_item);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        db = new InventoryItemDatabase(this);

        /*
            Set up cancel button click event.
        */

        Button cancelButton = findViewById(R.id.cancelButton);

        cancelButton.setOnClickListener(view -> {
            Intent intent = new Intent(AddItem.this, HomeActivity.class);
            startActivity(intent);
        });

        /*
            Set up save button click event.
        */

        Button saveButton = findViewById(R.id.saveButton);

        saveButton.setOnClickListener(view -> {
            EditText itemNameText = findViewById(R.id.addItemItemName);
            EditText itemDescriptionText = findViewById(R.id.addItemItemDescription);
            EditText itemQuantityText = findViewById(R.id.addItemItemQuantity);

            String itemName = itemNameText.getText().toString();
            String itemDescription = itemDescriptionText.getText().toString();
            int itemQuantity = Integer.parseInt(itemQuantityText.getText().toString());

            boolean result = db.addItem(itemName, itemDescription, itemQuantity);

            if (result) {
                Intent intent = new Intent(AddItem.this, HomeActivity.class);
                startActivity(intent);
            }
        });
    }
}