package com.zybooks.josephgoinscs360project;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/*
    * This java class file serves an the data access layer for users table.
    * It contains table creation and updating methods. It also contains methods
    * for validating users, existing users, and creating users.
*/
public class UserDatabase extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "users.db";
    private static final int VERSION = 1;

    public UserDatabase(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    private static final class UserTable {
        private static final String TABLE = "users";
        private static final String COL_ID = "_id";
        private static final String COL_USERNAME = "username";
        private static final String COL_PASSWORD = "password";
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + UserTable.TABLE + " (" +
                UserTable.COL_ID + " integer primary key autoincrement, " +
                UserTable.COL_USERNAME + " text, " +
                UserTable.COL_PASSWORD + " text)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists " + UserTable.TABLE);
        onCreate(db);
    }

    // Check valid login credentials
    public boolean validateUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();

        String sql = "select * from users where username = ? and password = ?";

        Cursor cursor = db.rawQuery(sql, new String[]{username, password});

        boolean isValid = cursor.moveToFirst();

        cursor.close();

        return isValid;
    }

    // Used to check if users exist before creating a new user.
    public boolean userExist(String username) {
        SQLiteDatabase db = getReadableDatabase();

        String sql = "select * from users where username = ?";

        Cursor cursor = db.rawQuery(sql, new String[]{username});

        boolean isValid = cursor.moveToFirst();

        cursor.close();

        return isValid;
    }

    public void createUser(String username, String password) {
        SQLiteDatabase db = getReadableDatabase();

        boolean alreadyUser = userExist(username);

        if (alreadyUser) return;

        String sql = "insert into users (username, password) values (?, ?)";

        db.execSQL(sql, new Object[]{username, password});
    }
}
