package com.zybooks.josephgoinscs360project;

public class InventoryItem {
    private String itemName;
    private String itemDescription;
    private int itemQuantity;

    public InventoryItem(String name, String description, int qty) {
        this.itemName = name;
        this.itemDescription = description;
        this.itemQuantity = qty;
    }

    /*
        GETTERS
    */

    public String getItemName() {
        return itemName;
    }

    public String getItemDescription() {
        return itemDescription;
    }

    public int getItemQuantity() {
        return itemQuantity;
    }

    /*
        * SETTERS
    */

    public void setItemQuantity(int qty) {
        this.itemQuantity = qty;
    }
}
