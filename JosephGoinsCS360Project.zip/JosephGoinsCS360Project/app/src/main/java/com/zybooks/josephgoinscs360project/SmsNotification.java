package com.zybooks.josephgoinscs360project;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class SmsNotification extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_sms_notification);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        /*
            Set up allow SMS notifications button click.
        */
        Button allowButton = findViewById(R.id.allowSMSNotifications);

        // If permission granted navigate home, otherwise request permission.
        // Here Used a lot of help from the Android Developer Run Time Permissions page.
        allowButton.setOnClickListener(view -> {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                    == PackageManager.PERMISSION_GRANTED) {

                Intent intent = new Intent(SmsNotification.this, HomeActivity.class);
                startActivity(intent);

            } else {
                requestPermissions(
                        new String[]{Manifest.permission.SEND_SMS},
                        100
                );
            }
        });

        /*
            Set up decline SMS notifications button click.
        */
        Button declineButton = findViewById(R.id.declineSMSNotifications);

        declineButton.setOnClickListener(view -> {
            Intent intent = new Intent(SmsNotification.this, HomeActivity.class);
            startActivity(intent);
        });

        /*
            Set up cancel button click.
        */
        Button cancelButton = findViewById(R.id.cancelSMSNotifications);

        cancelButton.setOnClickListener(view -> {
            Intent intent = new Intent(SmsNotification.this, HomeActivity.class);
            startActivity(intent);
        });
    }
}