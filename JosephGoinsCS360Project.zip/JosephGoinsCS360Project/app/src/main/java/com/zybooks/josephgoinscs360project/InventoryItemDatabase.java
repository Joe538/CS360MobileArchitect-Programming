package com.zybooks.josephgoinscs360project;

import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;
import java.util.Collection;

public class InventoryItemDatabase extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "inventory.db";
    private static final int VERSION = 1;

    public InventoryItemDatabase(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    private static final class InventoryTable {
        private static final String TABLE = "inventory";
        private static final String COL_ID = "_id";
        private static final String COL_NAME = "name";
        private static final String COL_DESCRIPTION = "description";
        private static final String COL_QUANTITY = "quantity";
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + InventoryItemDatabase.InventoryTable.TABLE + " (" +
                InventoryItemDatabase.InventoryTable.COL_ID + " integer primary key autoincrement, " +
                InventoryItemDatabase.InventoryTable.COL_NAME + " text, " +
                InventoryItemDatabase.InventoryTable.COL_DESCRIPTION + " text, " +
                InventoryItemDatabase.InventoryTable.COL_QUANTITY + " int)");
    }

    // Whenever a new version of the table is created, drop the old one, then create the new one
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists " + InventoryItemDatabase.InventoryTable.TABLE);
        onCreate(db);
    }

    // This adds an item to the inventory.db : It's called from AddItem.java
    public boolean addItem(String itemName, String itemDescription, int itemQuantity) {
        SQLiteDatabase db = getWritableDatabase();

        String sql = "insert into inventory (name, description, quantity) values (?, ?, ?)";

        try {
            db.execSQL(sql, new Object[]{itemName, itemDescription, itemQuantity});
            return true;
        }
        catch(SQLException e) {
            Log.e("DATABASE", "Failed to insert inventory item into the database.");
            return false;
        }
    }

    /*
        * getAllItems grabs the readable database, and creates the first
        * array list of items from the db. It creats a sql statement and then trys to execute it.
        * While there is another item in the cursor it will attempt to grab the columns in each
        * iteration. I used getColumnIndexOrThrow because it automatically throws an exception
        * when the index has unintended results such as -1 which was the warning when using
        * getColumnIndex. It then creates an InventoryItem model with it and adds it to the array.
        * Lastly, it returns an array of InventoryItem. : It's called from HomeActvity.java
    */
    public ArrayList<InventoryItem> getAllItems() {
        SQLiteDatabase db = getReadableDatabase();

        ArrayList<InventoryItem> items = new ArrayList<>();

        String sql = "select * from inventory";

        try (Cursor cursor = db.rawQuery(sql, null)) {
            while (cursor.moveToNext()) {
                String name = cursor.getString(
                        cursor.getColumnIndexOrThrow("name")
                );

                String description = cursor.getString(
                        cursor.getColumnIndexOrThrow("description")
                );

                int quantity = cursor.getInt(
                        cursor.getColumnIndexOrThrow("quantity")
                );

                InventoryItem item = new InventoryItem(
                        name, description, quantity
                );

                items.add(item);
            }
        }

        return items;
    }

    // Deletes the item based on name, it returns true or false to perform UI changes.
    public boolean deleteInventoryItem(String itemName) {
        SQLiteDatabase db = getWritableDatabase();

        String sql = "delete from inventory where name = ?";

        try {
            db.execSQL(sql, new String[]{itemName});
            return true;
        }
        catch (SQLException e) {
            Log.e("DATABASE", "Failed to delete item from inventory list.");
            return false;
        }
    }

    /*
        * Changes quantity using name for the search conditions.
        * It also sends the new quantity and returns a boolean
        * to let the adapter know to update the UI with success or not
        * from failure.
    */
    public boolean changeQuantityFromItem(String name, int quantity) {
        SQLiteDatabase db = getWritableDatabase();

        String sql = "update inventory set quantity = ? where name = ?";

        try {
            db.execSQL(sql, new Object[]{quantity, name});
            return true;
        }
        catch (SQLException e) {
            Log.e("DATABASE", "Failed to update item inventory quantity.");
            return false;
        }
    }
}
